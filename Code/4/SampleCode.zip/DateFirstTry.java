

public class DateFirstTry
{
    public String month; 
    public int day;
    public int year; //a four digit number.

    public void writeOutput( )
    {
        System.out.println(month + " " + day + ", " + year); 
    }
}
