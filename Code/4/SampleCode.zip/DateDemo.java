public class DateDemo{
	public static void main(String[] args){
		DateFirstTry d1=new DateFirstTry();
		DateSecondTry d2=new DateSecondTry();
		DateThirdTry d3=new DateThirdTry();
		//---------------------------
		//---Begin to Modify---
		//---------------------------
			
		//---------------------------
		//---End to Modify-----
		//---------------------------
		d1.writeOutput();
		d2.writeOutput();
		d3.writeOutput();
	}

}